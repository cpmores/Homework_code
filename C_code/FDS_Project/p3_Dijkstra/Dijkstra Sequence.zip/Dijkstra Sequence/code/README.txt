Please check the code in main.c , and the samples you may need are in the sample.txt
Thanks!